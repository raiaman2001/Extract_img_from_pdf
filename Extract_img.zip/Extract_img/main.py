from tkinter import*
from PIL import Image, ImageTk   
from pikepdf import Pdf, PdfImage
import os
from tkinter import filedialog,messagebox
root=Tk()
root.geometry("700x400")
root.title("Image Viewer")
root.resizable(False,False)

def openfile():
    global file_path
    file_path=filedialog.askopenfilename(initialdir=os.getcwd(),title="select Pdf file",
                                         filetype=(('PDF File','*.pdf'),('all files','*.*')))
    l1_ent.insert(END,file_path)
def extract():
        target_path=target.get()
        try:
            old_pdf = Pdf.open(file_path)
            page_1 = old_pdf.pages[0]

            # Check if there are images on the page
            image_keys = list(page_1.images.keys())
            if not image_keys:
                messagebox.showwarning("No Images", "No images found on the first page.")
                return

            raw_image = page_1.images[image_keys[0]]  # Get the first image
            pdf_image = PdfImage(raw_image)
            pdf_image.extract_to(fileprefix=target_path)  # Extract the image

            messagebox.showinfo("Success", "Image extracted successfully as 'extracted_image.png'.")

        except Exception as e:
            messagebox.showerror("Error", str(e))

image=ImageTk.PhotoImage(Image.open("back1.jpg"))
image_label=Label(root, image=image)
image_label.place(x=0,y=0)


l1=Label(root,text="Select Pdf:",font=("Bahnschrift",13,"bold"),bg="lightblue")
l1.place(x=165,y=65,width=90,height=30)
l1_ent=Entry(root,font=("Courier New",12))
l1_ent.place(x=260,y=65,width=250,height=30)

browse=Button(root,text="🔍",font=(12),bd=2,bg="lightblue",command=openfile)
browse.place(x=515,y=65,width=30,height=30)

target=StringVar()
l2=Label(root,text="Image Name:",font=("Bahnschrift",13,"bold"),bg="lightblue")
l2.place(x=165,y=105,width=110,height=30)
l2_ent=Entry(root,textvariable=target,font=("Courier New",12))
l2_ent.place(x=280,y=105,width=250,height=30)

extract_btn=Button(root,text="Extract Image",font=("Bahnschrift",13,"bold"),bd=2,bg="lightblue",command=extract)
extract_btn.place(x=310,y=150,width=120,height=30)

root.mainloop()